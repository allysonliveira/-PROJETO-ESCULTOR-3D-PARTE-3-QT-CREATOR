/****************************************************************************
** Meta object code from reading C++ file 'plotter.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.14.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/


#include <memory>
#include "../Projeto_Escultor3D_UnidadeIII/plotter.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'plotter.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.14.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_Plotter_t {
    QByteArrayData data[35];
    char stringdata0[349];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_Plotter_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_Plotter_t qt_meta_stringdata_Plotter = {
    {
QT_MOC_LITERAL(0, 0, 7), // "Plotter"
QT_MOC_LITERAL(1, 8, 14), // "alteraSlidersX"
QT_MOC_LITERAL(2, 23, 0), // ""
QT_MOC_LITERAL(3, 24, 14), // "alteraSlidersY"
QT_MOC_LITERAL(4, 39, 14), // "alteraSlidersZ"
QT_MOC_LITERAL(5, 54, 22), // "alteraSliderRaioEsfera"
QT_MOC_LITERAL(6, 77, 13), // "alteraSliderR"
QT_MOC_LITERAL(7, 91, 13), // "alteraSliderG"
QT_MOC_LITERAL(8, 105, 13), // "alteraSliderB"
QT_MOC_LITERAL(9, 119, 18), // "abreDialogEscultor"
QT_MOC_LITERAL(10, 138, 13), // "salvaEscultor"
QT_MOC_LITERAL(11, 152, 10), // "mudaPlanoZ"
QT_MOC_LITERAL(12, 163, 6), // "planoZ"
QT_MOC_LITERAL(13, 170, 15), // "acaoSelecionada"
QT_MOC_LITERAL(14, 186, 5), // "_acao"
QT_MOC_LITERAL(15, 192, 10), // "mudaXCaixa"
QT_MOC_LITERAL(16, 203, 2), // "_x"
QT_MOC_LITERAL(17, 206, 10), // "mudaYCaixa"
QT_MOC_LITERAL(18, 217, 2), // "_y"
QT_MOC_LITERAL(19, 220, 10), // "mudaZCaixa"
QT_MOC_LITERAL(20, 231, 2), // "_z"
QT_MOC_LITERAL(21, 234, 14), // "mudaRaioEsfera"
QT_MOC_LITERAL(22, 249, 3), // "_re"
QT_MOC_LITERAL(23, 253, 18), // "mudaRaioXEllipsoid"
QT_MOC_LITERAL(24, 272, 3), // "_rx"
QT_MOC_LITERAL(25, 276, 18), // "mudaRaioYEllipsoid"
QT_MOC_LITERAL(26, 295, 3), // "_ry"
QT_MOC_LITERAL(27, 299, 18), // "mudaRaioZEllipsoid"
QT_MOC_LITERAL(28, 318, 3), // "_rz"
QT_MOC_LITERAL(29, 322, 5), // "mudaR"
QT_MOC_LITERAL(30, 328, 2), // "_r"
QT_MOC_LITERAL(31, 331, 5), // "mudaB"
QT_MOC_LITERAL(32, 337, 2), // "_b"
QT_MOC_LITERAL(33, 340, 5), // "mudaG"
QT_MOC_LITERAL(34, 346, 2) // "_g"

    },
    "Plotter\0alteraSlidersX\0\0alteraSlidersY\0"
    "alteraSlidersZ\0alteraSliderRaioEsfera\0"
    "alteraSliderR\0alteraSliderG\0alteraSliderB\0"
    "abreDialogEscultor\0salvaEscultor\0"
    "mudaPlanoZ\0planoZ\0acaoSelecionada\0"
    "_acao\0mudaXCaixa\0_x\0mudaYCaixa\0_y\0"
    "mudaZCaixa\0_z\0mudaRaioEsfera\0_re\0"
    "mudaRaioXEllipsoid\0_rx\0mudaRaioYEllipsoid\0"
    "_ry\0mudaRaioZEllipsoid\0_rz\0mudaR\0_r\0"
    "mudaB\0_b\0mudaG\0_g"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_Plotter[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
      21,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       7,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    2,  119,    2, 0x06 /* Public */,
       3,    2,  124,    2, 0x06 /* Public */,
       4,    2,  129,    2, 0x06 /* Public */,
       5,    2,  134,    2, 0x06 /* Public */,
       6,    1,  139,    2, 0x06 /* Public */,
       7,    1,  142,    2, 0x06 /* Public */,
       8,    1,  145,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
       9,    0,  148,    2, 0x0a /* Public */,
      10,    0,  149,    2, 0x0a /* Public */,
      11,    1,  150,    2, 0x0a /* Public */,
      13,    1,  153,    2, 0x0a /* Public */,
      15,    1,  156,    2, 0x0a /* Public */,
      17,    1,  159,    2, 0x0a /* Public */,
      19,    1,  162,    2, 0x0a /* Public */,
      21,    1,  165,    2, 0x0a /* Public */,
      23,    1,  168,    2, 0x0a /* Public */,
      25,    1,  171,    2, 0x0a /* Public */,
      27,    1,  174,    2, 0x0a /* Public */,
      29,    1,  177,    2, 0x0a /* Public */,
      31,    1,  180,    2, 0x0a /* Public */,
      33,    1,  183,    2, 0x0a /* Public */,

 // signals: parameters
    QMetaType::Void, QMetaType::Int, QMetaType::Int,    2,    2,
    QMetaType::Void, QMetaType::Int, QMetaType::Int,    2,    2,
    QMetaType::Void, QMetaType::Int, QMetaType::Int,    2,    2,
    QMetaType::Void, QMetaType::Int, QMetaType::Int,    2,    2,
    QMetaType::Void, QMetaType::Int,    2,
    QMetaType::Void, QMetaType::Int,    2,
    QMetaType::Void, QMetaType::Int,    2,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,   12,
    QMetaType::Void, QMetaType::QString,   14,
    QMetaType::Void, QMetaType::Int,   16,
    QMetaType::Void, QMetaType::Int,   18,
    QMetaType::Void, QMetaType::Int,   20,
    QMetaType::Void, QMetaType::Int,   22,
    QMetaType::Void, QMetaType::Int,   24,
    QMetaType::Void, QMetaType::Int,   26,
    QMetaType::Void, QMetaType::Int,   28,
    QMetaType::Void, QMetaType::Int,   30,
    QMetaType::Void, QMetaType::Int,   32,
    QMetaType::Void, QMetaType::Int,   34,

       0        // eod
};

void Plotter::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<Plotter *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->alteraSlidersX((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2]))); break;
        case 1: _t->alteraSlidersY((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2]))); break;
        case 2: _t->alteraSlidersZ((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2]))); break;
        case 3: _t->alteraSliderRaioEsfera((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2]))); break;
        case 4: _t->alteraSliderR((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 5: _t->alteraSliderG((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 6: _t->alteraSliderB((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 7: _t->abreDialogEscultor(); break;
        case 8: _t->salvaEscultor(); break;
        case 9: _t->mudaPlanoZ((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 10: _t->acaoSelecionada((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 11: _t->mudaXCaixa((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 12: _t->mudaYCaixa((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 13: _t->mudaZCaixa((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 14: _t->mudaRaioEsfera((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 15: _t->mudaRaioXEllipsoid((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 16: _t->mudaRaioYEllipsoid((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 17: _t->mudaRaioZEllipsoid((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 18: _t->mudaR((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 19: _t->mudaB((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 20: _t->mudaG((*reinterpret_cast< int(*)>(_a[1]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (Plotter::*)(int , int );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&Plotter::alteraSlidersX)) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (Plotter::*)(int , int );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&Plotter::alteraSlidersY)) {
                *result = 1;
                return;
            }
        }
        {
            using _t = void (Plotter::*)(int , int );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&Plotter::alteraSlidersZ)) {
                *result = 2;
                return;
            }
        }
        {
            using _t = void (Plotter::*)(int , int );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&Plotter::alteraSliderRaioEsfera)) {
                *result = 3;
                return;
            }
        }
        {
            using _t = void (Plotter::*)(int );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&Plotter::alteraSliderR)) {
                *result = 4;
                return;
            }
        }
        {
            using _t = void (Plotter::*)(int );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&Plotter::alteraSliderG)) {
                *result = 5;
                return;
            }
        }
        {
            using _t = void (Plotter::*)(int );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&Plotter::alteraSliderB)) {
                *result = 6;
                return;
            }
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject Plotter::staticMetaObject = { {
    QMetaObject::SuperData::link<QWidget::staticMetaObject>(),
    qt_meta_stringdata_Plotter.data,
    qt_meta_data_Plotter,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *Plotter::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *Plotter::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_Plotter.stringdata0))
        return static_cast<void*>(this);
    return QWidget::qt_metacast(_clname);
}

int Plotter::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 21)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 21;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 21)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 21;
    }
    return _id;
}

// SIGNAL 0
void Plotter::alteraSlidersX(int _t1, int _t2)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void Plotter::alteraSlidersY(int _t1, int _t2)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}

// SIGNAL 2
void Plotter::alteraSlidersZ(int _t1, int _t2)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}

// SIGNAL 3
void Plotter::alteraSliderRaioEsfera(int _t1, int _t2)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))) };
    QMetaObject::activate(this, &staticMetaObject, 3, _a);
}

// SIGNAL 4
void Plotter::alteraSliderR(int _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 4, _a);
}

// SIGNAL 5
void Plotter::alteraSliderG(int _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 5, _a);
}

// SIGNAL 6
void Plotter::alteraSliderB(int _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 6, _a);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
